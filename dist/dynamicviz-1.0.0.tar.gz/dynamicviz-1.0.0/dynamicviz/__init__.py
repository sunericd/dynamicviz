'''DynamicViz provides a wrapper for generating and interpreting dynamic visualizations from traditional static dimensionality reduction visualization methods'''

__version__ = "1.0.0"